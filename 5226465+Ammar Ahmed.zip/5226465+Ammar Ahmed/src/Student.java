//@autor 5226465 Ammar Ahmed
//version 1.0
// Studentverwaltung programm


import java.util.ArrayList;


public class Student { // class student
	
	private int index;
	private String strmatr;
	private String strname;
	private String strvorname;
	private Leistung leistung;
	private ArrayList<Leistung> Noten;
	
	
	
	public Student(int index , String matr, String name, String vorname, ArrayList<Leistung> temp ) { // constructor der klasse student
		
		this.setStrmatr(matr);
		this.setStrname(name);
		this.setStrvorname(vorname);
		this.Noten = temp;
		this.index = index;
	}
	
	public int getIndex() { // get index methode
		return this.index;
	}

	public String getStrmatr() { // getstrmatr methode
		return strmatr;
	}

	public void setStrmatr(String strmatr) { // set matrikel nummer method
		this.strmatr = strmatr;
	}

	public Leistung getLeistung() { // get leistung method
		return leistung;
	}

	public void setLeistung(Leistung leistung) { // set leistung method
		this.leistung = leistung;
	}

	public String getStrname() {
		return strname;
	}

	public void setStrname(String strname) {
		this.strname = strname;
	}

	public String getStrvorname() {
		return strvorname;
	}

	public void setStrvorname(String strvorname) {
		this.strvorname = strvorname;
	}

	public ArrayList<Leistung> getNoten(){
		return this.Noten;
	}
	public double getDurschnitt() {
		double sum = 0;
		for(int i = 0; i < this.Noten.size(); i++) {
			sum += this.Noten.get(i).getDbergebnis();
		}
		sum /= this.Noten.size();
		sum*=100;
		return sum;
	}
	
	public int getsumcp() {
		
		int sum=0;
		for(int i = 0; i<this.Noten.size(); i++) {
			sum+= this.Noten.get(i).icp;
		
		}
	      
		return sum;
		
	}
	
	public int getNichtBestandenModul() {
		int anzahl=0;
		for (int i = 0; i<this.Noten.size(); i++) {
			
			if (this.Noten.get(i).getDbergebnis()<50   )
				
				anzahl++;
						
			
		}//end for schleife
		
		return anzahl;
	}//end getnichtbestandenmodul methode
	
	
}// end class Student
