//@autor 5226465 Ammar Ahmed
//version 1.0
// Studentverwaltung programm


import java.util.ArrayList;
import java.util.Scanner;


public class Studentverwaltung {
	
	public int StudentNumber;
	
	
	
	ArrayList <Student> lststudent = new ArrayList <Student>(); // erstellung eines array von studenten
	
	public ArrayList<Leistung> lstleistung;
	
	public Studentverwaltung(){
		this.lstleistung = new ArrayList<Leistung>();
	}
	
	
	public void studenthinzu(String matr, String name, String vorname, ArrayList<Leistung> temp) { // new student hinzuf�gen methode
		
		
		lststudent.add(new Student( StudentNumber,matr,  name,  vorname, temp )) ;
		
	}
	
	public ArrayList<Leistung> leistunghinzu (String ver, int sws, int cp,String modul, String pr�fer, double ergebnis) { // new leistung hinzuf�gen methode
		
		lstleistung.add(new Leistung (  ver,  sws,  cp,modul, pr�fer,ergebnis));
		return  lstleistung;
	}
	
	public void studentbearbeiten (int position, String ver, int sws, int cp,String matr, String name, String vorname, String modul, String pr�fer, double ergebnis) { // student bearbeiten methode
		
	 lststudent.set(position, new Student(StudentNumber,matr,  name,  vorname, setleistung(ver, position,  sws,  cp,modul, pr�fer, ergebnis) ));
		
	}
	
	public ArrayList<Leistung> setleistung(String ver, int sws, int cp,int position, String modul, String pr�fer, double ergebnis){ // leistung edit method
		
		lstleistung.set(position, new Leistung ( ver,  sws,  cp,modul, pr�fer, ergebnis));
		return lstleistung;
		
	}
	
	public void studentl�schen (int position) { // student delete methode
		
		lststudent.remove(position);
		lstleistung.remove(position);
	}
	
	public void printstudent () { // �student print mehthode 
		
        for(int i = 0; i < lststudent.size(); i++) {   
			
			System.out.println("Student " + i + " : ");
			
			System.out.println("Matrnum :"+lststudent.get(i).getStrmatr()+"\t Name :"+lststudent.get(i).getStrname()+"\t Vorname :"+lststudent.get(i).getStrvorname() );
		
		} // end for schleife
	} // end printstudent method
	
	
	public void printleistung(int position ) { //prinbt leistung methode
		Student s = null;
		for(int i = 0; i < lststudent.size(); i++) {   
			 s = lststudent.get(i);
			if(s.getIndex() == position) 
				break;
			//System.out.println(" Modulname :" +lstleistung.get(position).strmodul +"\t Pr�fer :"+lstleistung.get(position).strpr�fer+"\t Ergebnis :"+lstleistung.get(position).getDbergebnis());
		}// end for schleife
		ArrayList<Leistung> temp = s.getNoten();
		for(int i = 0 ; i < temp.size(); i++) {
			Leistung l = temp.get(i);
			System.out.println(" Modulname :" +l.strmodul +"\t Pr�fer :"+l.strpr�fer+"\t Ergebnis :"+l.getDbergebnis() + "\t Verantwortliche :"+l.strver + "\t cp :"+ l.icp + "\t sws :" +l.isws);
		}
		
	}// end printleistung method
	
	
	public static void main (String args []) { // main methode
		
		
		Studentverwaltung studentverwaltung = new Studentverwaltung ();
		
		studentverwaltung.StudentNumber = 0;
		
		String  name, vorname, modulname = null, pr�fer = null, matrnum, ver=null;
		int position,  sws = 0,  cp = 0;
	
		double ergebnis = 0;
	
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Bitte geben Sie eine Nummer f�r die Transaktion ein"); // menu
	System.out.println("1- Student hinzuf�gen");
	System.out.println("2- Bestehende Student bearbeiten");
	System.out.println("3- Bestehende Student l�schen");
	System.out.println("4- Studentenlist ausgeben");
	System.out.println("5- Module eines Student ausgeben");
	System.out.println("6- Tabellarische Leistungs�bersicht ausgeben");
	
	int iwahl = sc.nextInt();
	
	
    
	while (iwahl!=7) {
		
		switch (iwahl) {
		
		case 1: Scanner scanner = new Scanner(System.in);
			ArrayList<Leistung> temp = new ArrayList<Leistung>();
		System.out.println("Bitte Matrnum eingeben");
		 matrnum= scanner.next();
		
		System.out.println("Bitte Name eingeben");
		name = scanner.next();
		
		System.out.println("Bitte Vorname eingeben");
		
		vorname = scanner.next() ;
		
		studentverwaltung.StudentNumber++;
		System.out.println("Bitte Nummer der Modulen eingeben");
		int n;
		n = scanner.nextInt();
		for(int i = 0; i < n; i++) {
			System.out.println("Bitte modulname eingeben");
			
			modulname = scanner.next();
			
			System.out.println("Bitte Pr�fer eingeben");
			
			pr�fer = scanner.next() ;
			
			System.out.println("Bitte cps eingeben");
			
			cp = scanner.nextInt();
			
			System.out.println("Bitte SWS eingeben");
			
			sws = scanner.nextInt();
			
			System.out.println("Bitte verantworltiche eingeben");
			
			ver = scanner.next();
			
			System.out.println("Bitte Ergebnis eingeben");
			ergebnis = scanner.nextDouble() ;
			temp = studentverwaltung.leistunghinzu(ver,  sws,  cp,modulname, pr�fer, ergebnis);
			
		}
		
		
		
		
		studentverwaltung.studenthinzu(matrnum, name, vorname, temp);
		
		break;
		
		case 2: Scanner scanner2 = new Scanner ( System.in);
		
				System.out.println("Bitte index nummer eingeben");
				position = scanner2.nextInt();
				
				System.out.println("Bitte Matrnum eingeben");
				 matrnum= scanner2.next();
				
				System.out.println("Bitte Name eingeben");
				name = scanner2.next();
				
				System.out.println("Bitte Vorname eingeben");
				
				vorname = scanner2.next() ;
				
				System.out.println("Bitte modulname eingeben");
				
				modulname = scanner2.next();
				
				System.out.println("Bitte Pr�fer eingeben");
				
				pr�fer = scanner2.next() ;
				
				System.out.println("Bitte Ergebnis eingeben");
				
				ergebnis = scanner2.nextDouble() ;
				
				studentverwaltung.studentbearbeiten(position, ver,  sws,  cp,matrnum, name, vorname, modulname, pr�fer, ergebnis);
				break;
				
		case 3: Scanner scanner3 = new Scanner(System.in);
		
				System.out.println("Bitte index nummer eingeben");
				position= scanner3.nextInt();
				
				studentverwaltung.studentl�schen(position);
				break;
				
		case 4:  
				studentverwaltung.printstudent();
				break;
				
		case 5: Scanner scanner4 = new Scanner(System.in);
		
				System.out.println("Bitte index nummer eingeben");
				position= scanner4.nextInt();
				studentverwaltung.printleistung(position);
				break;
				
		case 6: 
			   
			Scanner scanner5 = new Scanner(System.in);
			System.out.println("Bitte index nummer eingeben");
			position= scanner5.nextInt();
			System.out.println("Durchschnittsleistung in Prozent :" + studentverwaltung.lststudent.get(position).getDurschnitt() + "\t Anzahl der erreichten Credit Points :" +studentverwaltung.lststudent.get(position).getsumcp()+ "\t  Anzahl der nicht bestandenen Pr�fungsleistungen :"+studentverwaltung.lststudent.get(position).getNichtBestandenModul());
			break;
			
		default: System.out.print("good luck next time");
		break;
		
	}// end switch case

		System.out.println("Bitte geben Sie eine Nummer f�r die Transaktion ein");
		System.out.println("1- Student hinzuf�gen");
		System.out.println("2- Bestehende Student bearbeiten");
		System.out.println("3- Bestehende Student l�schen");
		System.out.println("4- Studentenlist ausgeben");
		System.out.println("5- Leistung eines Student ausgeben");
		System.out.println("6- Tabellarische Leistungs�bersicht ausgeben");
		
		iwahl = sc.nextInt();
		
		
} // end while schleife
	} // end main class
	}// end class Studentverwaltung
