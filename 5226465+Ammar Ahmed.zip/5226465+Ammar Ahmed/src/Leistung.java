//@autor 5226465 Ammar Ahmed
//version 1.0
// Studentverwaltung programm


public class Leistung {

	public String strmodul;
	public String strpr�fer;
	private double dbergebnis;
	public String strver;
	public int isws;
	public int icp;
	
	public Leistung ( String ver, int sws, int cp, String modul, String pr�fer, double ergebnis ) {
		
		this.strmodul = modul;
		this.strpr�fer = pr�fer;
		this.setDbergebnis(ergebnis);
		
		this.strver = ver;
		this.isws = sws;
		this.icp = cp;
	}

	public Leistung() {
		// TODO Auto-generated constructor stub
	}

	public double getDbergebnis() {
		return dbergebnis;
	}

	public void setDbergebnis(double dbergebnis) {
		this.dbergebnis = dbergebnis;
	}
	
}
